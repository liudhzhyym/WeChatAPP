Page({
  data: {
    boards: [
      { key: 'in_theaters', name: '正在热映' },
      { key: 'coming_soon', name: '即将上映' },
      { key: 'top250', name: 'T0P250' },
      // { key: 'weekly', name: '口碑榜' },
      { key: 'us_box', name: '北美票房榜' },
      // { key: 'new_movies', name: '新片榜' }
    ]
  }
})





